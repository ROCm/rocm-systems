set pagination off
set confirm off
set breakpoint pending on
set debuginfod enabled off
catch exec
run
break main
continue
info sharedlibrary
info functions EventState::set_event
break rocjitsu::EventState::set_event(void*)
condition 3 *(unsigned int*)$rsi == 6
commands 3
silent
printf "EVENT6 SET thread=%d\n", $_thread
bt 14
continue
end
break rocjitsu::EventState::destroy_event(void*)
condition 4 *(unsigned int*)$rsi == 6
commands 4
silent
printf "EVENT6 DESTROY thread=%d\n", $_thread
bt 14
continue
end
continue
