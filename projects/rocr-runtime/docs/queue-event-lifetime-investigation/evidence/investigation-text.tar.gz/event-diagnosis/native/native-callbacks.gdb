set pagination off
set breakpoint pending on
break rocr::AMD::AqlQueue::ExceptionHandler
commands
silent
printf "native ExceptionHandler called\n"
continue
end
break rocr::AMD::AqlQueue::DynamicQueueEventsHandler
commands
silent
printf "native DynamicQueueEventsHandler called\n"
continue
end
run
