# ROCr queue-event reproducer without rocJITsu

Source: `queue-event-repro.cpp`. Uses HSA queue creation/destruction and real KFD ioctls. No rocJITsu, HIP, GEMM library or GPU kernel dispatch. Requires a physical AMD GPU with KFD access.

The program creates and destroys four AQL queues. Its ioctl interposer delays background SET_EVENT by 100 ms, forwarding every real request unchanged. It tracks any DESTROY_EVENT while a write to that same event is outstanding and prints failed real SET_EVENT results. The delay makes the existing teardown window observable; this is injected timing, not a naturally occurring crash reproduction.

Build against an installed ROCm prefix:

```sh
c++ -std=c++17 -O2 -pthread -Wl,--export-dynamic \
  -I/opt/rocm/include queue-event-repro.cpp \
  -L/opt/rocm/lib -Wl,-rpath,/opt/rocm/lib \
  -lhsa-runtime64 -ldl -o queue-event-repro

env -u LD_PRELOAD ROCR_VISIBLE_DEVICES=0 HSA_ENABLE_INTERRUPT=1 ./queue-event-repro
```

Set `LD_LIBRARY_PATH` to select a particular runtime build. To compare matching builds, use the same compiler/thunk dependencies, with only the runtime directory changed. On this host, use environments saved in `reproducer-results.json`; no emulator is preloaded. `reproducer-receipt.json` records SHA256 digests and observed process mappings, confirming real runtime paths and no rocJITsu library loaded.

Failure signature on the original runtime:

```text
Delayed KFD SET_EVENT id=3 failed: result=-1 errno=22
Queue event lifetime: delayed writes=10, overlapping destroys=1
Queue event destroyed during an outstanding callback write
```

Exit 1; errno 22 is EINVAL. Event IDs/delayed-write counts can vary. Fixed runtime reports zero overlapping destroys and exits 0.

Native validation on 2026-10-16 (toga-6-shark52):

- Shark52 physical gfx1201: original artifact runtime fails 3/3; fixed Systems d68cd7890a2 passes 3/3, each with 10 delayed writes. Earlier 1ms,10–150us and scheduling experiments did not reproduce;100ms delay is needed by this reproducer on native hardware. No native unmodified-timing failure claimed.
- SharkMi300X4 physical gfx942, installed ROCm 7.2.1: fails 3/3 with 15 delayed writes, one overlapping destroy and real SET_EVENT EINVAL. Source digest and environment in `mi300x-environment.log`; logs `repro-1.log` through `repro-3.log`. Fixed runtime not built or tested on this worker.
- The published PR's regression still uses 1 ms and 64 queue creations, and was qualified under emulation. This standalone native source is a separate diagnostic artifact; no PR branch/description changes or network publication made in this step.

Local receipts/logs live beside this README. Worker execution-only directory: `~/workspace/results/rocm-systems-toga-6-shark52-queue-event-native` on SharkMi300X4.
