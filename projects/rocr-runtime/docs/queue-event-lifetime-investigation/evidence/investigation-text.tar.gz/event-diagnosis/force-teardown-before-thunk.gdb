set pagination off
set confirm off
set breakpoint pending on
set debuginfod enabled off
set print thread-events off
catch exec
run
break main
continue
python
import gdb
class HoldLateSet(gdb.Breakpoint):
    def __init__(self):
        super().__init__('hsaKmtSetEvent')
        self.count = 0
    def stop(self):
        event_id = int(gdb.parse_and_eval('*(unsigned int*)$rdi'))
        if event_id != 6: return False
        frame=gdb.newest_frame()
        names=[]
        while frame is not None:
            names.append(frame.name() or '')
            frame=frame.older()
        if not any('AqlQueue::ExceptionHandler' in n for n in names): return False
        self.count += 1
        if self.count == 3:
            gdb.write('HOLD FINAL EXCEPTION SET after signal value update\n')
            return True
        return False
hold=HoldLateSet()
end
continue
bt 14
disable 3
break rocjitsu::EventState::destroy_event(void*)
condition 4 *(unsigned int*)$rsi == 6
set scheduler-locking on
thread 1
continue
printf "MAIN DESTROYS EVENT6 WHILE CALLBACK SET IS PAUSED\n"
bt 14
finish
disable 4
set scheduler-locking off
continue
