set pagination off
set confirm off
set breakpoint pending on
set follow-exec-mode same
break rocjitsu::EventState::set_event(void*)
condition 1 *(unsigned int*)$rsi == 6
commands 1
silent
printf "EVENT6 SET thread=%d\n", $_thread
bt 14
continue
end
break rocjitsu::EventState::destroy_event(void*)
condition 2 *(unsigned int*)$rsi == 6
commands 2
silent
printf "EVENT6 DESTROY thread=%d\n", $_thread
bt 14
continue
end
run
