// Copyright Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier: MIT
#include <hsa/hsa.h>
#include <cstdio>
static hsa_agent_t gpu{};
static hsa_status_t find(hsa_agent_t agent, void*) {
 hsa_device_type_t type; auto s=hsa_agent_get_info(agent,HSA_AGENT_INFO_DEVICE,&type);
 if(s==HSA_STATUS_SUCCESS && type==HSA_DEVICE_TYPE_GPU) gpu=agent;
 return s;
}
int main() {
 if(hsa_init()!=HSA_STATUS_SUCCESS) return 1;
 if(hsa_iterate_agents(find,nullptr)!=HSA_STATUS_SUCCESS || !gpu.handle) return 2;
 for(int i=0;i<64;i++) {
  hsa_queue_t* queue{};
  if(hsa_queue_create(gpu,64,HSA_QUEUE_TYPE_MULTI,nullptr,nullptr,0,0,&queue)!=HSA_STATUS_SUCCESS) return 3;
  if(hsa_queue_destroy(queue)!=HSA_STATUS_SUCCESS) return 4;
 }
 auto s=hsa_shut_down(); std::printf("queue teardown status=%u\n",s);return s==HSA_STATUS_SUCCESS?0:5;
}
