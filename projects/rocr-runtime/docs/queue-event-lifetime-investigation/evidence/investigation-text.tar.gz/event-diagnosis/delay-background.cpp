// Copyright Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier: MIT
#include <atomic>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <dlfcn.h>
#include <mutex>
#include <pthread.h>
#include <unordered_map>
#include <unistd.h>
namespace {
const pthread_t main_thread = pthread_self();
std::mutex event_lock;
std::unordered_map<uint32_t, unsigned> pending;
std::atomic<unsigned> delays{}, overlaps{};
__attribute__((destructor)) void report() {
  fprintf(stderr, "queue event regression: delays=%u overlaps=%u\n", delays.load(), overlaps.load());
  if (overlaps.load() || !delays.load()) _Exit(99);
}
}
extern "C" int ioctl(int fd, unsigned long req, ...) {
  va_list ap; va_start(ap, req); void* arg=va_arg(ap,void*); va_end(ap);
  static auto next=reinterpret_cast<int(*)(int,unsigned long,void*)>(dlsym(RTLD_NEXT,"ioctl"));
  const bool delay = (req & 0xffff)==0x4b0a && arg && !pthread_equal(pthread_self(), main_thread);
  const bool destroy = (req & 0xffff)==0x4b09 && arg;
  const uint32_t id = delay || destroy ? *static_cast<uint32_t*>(arg) : 0;
  if (delay) {
    { std::lock_guard<std::mutex> guard(event_lock); ++pending[id]; }
    ++delays;
    usleep(1000);
  }
  if (destroy) {
    std::lock_guard<std::mutex> guard(event_lock);
    if (pending[id]) ++overlaps;
  }
  const int result = next(fd,req,arg);
  if (delay) { std::lock_guard<std::mutex> guard(event_lock); --pending[id]; }
  return result;
}
