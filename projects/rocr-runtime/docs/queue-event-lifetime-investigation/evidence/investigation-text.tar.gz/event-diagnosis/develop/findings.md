# Current develop verification

ROCr `6191d1527b29369b6558ff7cc246281704e22224` was built from a clean source tree into a fresh out-of-tree build. Runtime host compiler Clang23.1.0; support shader/compiler config shim imports ROCm clang24 and llvm-objcopy. Reproducer amdclang++20; headers copied from the same checkout. Complete configuration/build commands and logs are in this directory.

The native failure is established: one user queue suffices; delayed mode fails5/5, zero-delay mode passes5/5; current-header repeat3/3 each. Error is real KFD SET_EVENT EINVAL while all public HSA calls return success. Process maps identify the newly built runtime and no rocJITsu. Runtime sha256 is in current-develop-results.json. Existing fixed-runtime comparisons are historical against an earlier base, not a same-head fix comparison.

The exact traced native callback is DynamicQueueEventsHandler<false>, not ExceptionHandler. Destroy stack: hsa_shut_down → Runtime::Unload → GpuAgent::ReleaseResources → AqlQueue::~AqlQueue. SET_EVENT stack: AsyncEventsLoop → DynamicQueueEventsHandler<false> → hsa_signal_store_screlease → thunk/ioctl. User queues were already destroyed; the overlap occurs on the final internal queue during hsa_shut_down. Both callback paths publish DONE before event notification finishes, but only the dynamic path is directly traced here.

Observed runtime bug: borrowed event lifetime shorter than retained callback signal lifetime. Potential use-after-free before entering ioctl is plausible from the raw event pointer; not separately demonstrated and not claimed as a native crash. Host scheduling delay is intentional100ms. Do not describe ordinary native failure frequency from these stress tests.

User explicitly prohibited creating an issue until instructed. No issue, PR edit, comment, push, or merge in this task. Draft issue is local and self-contained with source. Duplicate searches found separate async-exit/busy-poll issues, no exact matching title found; not an exhaustive duplicate audit.


2026-10-16 simplicity follow-up: prefer `simple/queue-lifecycle.cpp` and separate `simple/delay-set-event.cpp`, documented in `simple/README.md`. Final-source controls: plain3/3 and delay0 3/3 exit0/no internal error; delay100ms3/3 exit0 with actual SET_EVENT EINVAL, plus independent syscall traces. Same pinned develop/gfx1201. The preferred program no longer asserts overlap or exits1 for an internal error. Previous reproducer/draft preserved as historical diagnostic evidence. No native unmodified-timing crash or new publication.
