A standalone HSA program exposes a queue-event lifetime problem in unmodified `rocm-systems` develop at `6191d1527b29369b6558ff7cc246281704e22224`. It creates one AQL queue, destroys it, then calls `hsa_shut_down()`. When background KFD event writes are delayed by 100 ms, ROCr destroys an event while a callback still has a write outstanding. The real kernel `AMDKFD_IOC_SET_EVENT` then returns `EINVAL`.

The public `hsa_queue_create`, `hsa_queue_destroy`, and `hsa_shut_down` calls all return `HSA_STATUS_SUCCESS`. The reproducer exits with failure because it detects the internal event destruction/write overlap. This report concerns internal shutdown synchronization; it does not demonstrate incorrect kernel output or an ordinary application crash.

The problem was initially noticed as an intermittent shutdown warning during a CPU-emulated TensileLite race-detection workload. The standalone reproducer below does not use rocJITsu, HIP, TensileLite, or hipBLASLt, and dispatches no GPU kernels. Native tests use the real KFD driver.

## Verified environment and results

- Unmodified ROCr source: ROCm/rocm-systems develop `6191d1527b29369b6558ff7cc246281704e22224`; Release build of `projects/rocr-runtime`, including its thunk implementation.
- Native GPU: `gfx1201`, PCI device `1002:7551`; one GPU visible using `ROCR_VISIBLE_DEVICES=0`.
- Ubuntu 24.04.5 LTS; Linux `7.0.0-31-generic`.
- Runtime host compiler: upstream Clang 23.1.0. ROCm Clang 24 was used for the runtime's support kernels. The test program was compiled with installed `amdclang++`, AMD Clang 20 from ROCm 7.1.0, against the current runtime headers.
- Current-develop test with a 100 ms event-write delay: five of five runs failed. Same program with delay zero: five of five passed. A repeat against current headers reproduced the same result in three of three runs per mode.
- A preceding four-queue variant also failed in three of three native runs on MI300X `gfx942` with installed ROCm 7.2.1. Current develop was built and verified locally on gfx1201; it was not built on the MI300X machine.

The delay deliberately widens a possible thread scheduling interval. Every real ioctl is forwarded unchanged. No naturally occurring native crash is claimed, and the delay-zero control still has instrumentation installed.

## Reproduction

Build ROCr from the revision above using the normal project configuration and dependencies. Select the resulting runtime library explicitly. Save the program below as `queue-event-repro.cpp`.

```sh
# Set these to the source checkout and built ROCr directories.
ROCR_SOURCE=/path/to/rocm-systems/projects/rocr-runtime
ROCR_BUILD=/path/to/rocr-build

# The source headers live directly in inc; provide the hsa/ include layout.
mkdir -p repro-include
ln -s "$ROCR_SOURCE/runtime/hsa-runtime/inc" repro-include/hsa

amdclang++ -std=c++17 -O2 -pthread -Wl,--export-dynamic \
  -Irepro-include queue-event-repro.cpp \
  -L"$ROCR_BUILD/rocr/lib" -lhsa-runtime64 -ldl -o queue-event-repro

# Include matching dependency libraries in LD_LIBRARY_PATH if needed.
export LD_LIBRARY_PATH="$ROCR_BUILD/rocr/lib:$ROCR_BUILD/libhsakmt/lib:$LD_LIBRARY_PATH"

env -u LD_PRELOAD ROCR_VISIBLE_DEVICES=0 HSA_ENABLE_INTERRUPT=1 \
  ./queue-event-repro 100000

# Same code, with the intentional delay disabled:
env -u LD_PRELOAD ROCR_VISIBLE_DEVICES=0 HSA_ENABLE_INTERRUPT=1 \
  ./queue-event-repro 0
```

Observed failure:

```text
GPU=gfx1201; callback delay=100000 us
Delayed KFD SET_EVENT id=3 failed: result=-1 errno=22
hsa_queue_create, hsa_queue_destroy, hsa_shut_down all returned SUCCESS
Queue event lifetime: delayed writes=4, overlapping destroys=1
Queue event destroyed during an outstanding callback write
```

The process exits 1; event IDs and write counts can vary. Expected behavior is no event destruction while a callback still uses it, no internal `SET_EVENT` failure, and exit 0. The delay-zero control reports `overlapping destroys=0` and exits 0. A configuration with no GPU or no background event writes returns 77.

## Evidence for the lifetime problem

A diagnostic build of the reproducer recorded the overlapping calls' stacks. The delayed write came from `Runtime::AsyncEventsLoop` through `AqlQueue::DynamicQueueEventsHandler<false>` and `hsa_signal_store_screlease`. Event destruction came from `hsa_shut_down` through `Runtime::Unload`, `GpuAgent::ReleaseResources`, and `AqlQueue::~AqlQueue`. It occurred after the application queue had been destroyed, while shutdown released ROCr's final internal queue. A native `strace` also recorded successful `AMDKFD_IOC_DESTROY_EVENT` followed by `AMDKFD_IOC_SET_EVENT = -1 EINVAL` on the callback thread.

The source shows why completion-state publication can precede the last event use:

- [DynamicQueueEventsHandler](https://github.com/ROCm/rocm-systems/blob/6191d1527b29369b6558ff7cc246281704e22224/projects/rocr-runtime/runtime/hsa-runtime/core/runtime/amd_aql_queue.cpp#L1383) copies the signal handle, publishes `ERROR_HANDLER_DONE`, then stores the signal value.
- [InterruptSignal::StoreRelease](https://github.com/ROCm/rocm-systems/blob/6191d1527b29369b6558ff7cc246281704e22224/projects/rocr-runtime/runtime/hsa-runtime/core/runtime/interrupt_signal.cpp#L133) writes the signal value before calling `SetEvent`.
- [AqlQueue::~AqlQueue](https://github.com/ROCm/rocm-systems/blob/6191d1527b29369b6558ff7cc246281704e22224/projects/rocr-runtime/runtime/hsa-runtime/core/runtime/amd_aql_queue.cpp#L397) destroys the queue's signal handles and destroys the shared event when the queue count reaches zero.
- [AsyncEventsLoop](https://github.com/ROCm/rocm-systems/blob/6191d1527b29369b6558ff7cc246281704e22224/projects/rocr-runtime/runtime/hsa-runtime/core/runtime/runtime.cpp#L2075) releases its retained signal only after the callback returns. That retention protects the signal object, while the interrupt signal holds the shared queue event as a borrowed pointer.

The exception callback uses a similar publish-done-then-store sequence, but the traced native failure here was the queue-inactive/dynamic callback. The observed ordering is enough to establish an event lifetime problem; the best ownership or synchronization fix is left for ROCr maintainers to assess.

<details>
<summary>Standalone reproducer source</summary>

```cpp
// Copyright Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier: MIT

// Standalone ROCr queue-event lifetime reproducer on physical KFD hardware.
// No rocJITsu, HIP, GEMM library, or GPU kernel dispatch is required.
#include <hsa/hsa.h>

#include <atomic>
#include <cerrno>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <dlfcn.h>
#include <mutex>
#include <pthread.h>
#include <unistd.h>
#include <unordered_map>

namespace {
struct EventWrites {
  pthread_t main_thread = pthread_self();
  std::mutex mutex;
  std::unordered_map<uint32_t, unsigned> pending;
  std::atomic<unsigned> delays{0};
  std::atomic<unsigned> overlaps{0};
};

// Keep instrumentation available during library static teardown as well.
EventWrites *const writes = new EventWrites;
unsigned delay_us = 100000;

hsa_status_t FindGpu(hsa_agent_t agent, void *data) {
  hsa_device_type_t type;
  const hsa_status_t status =
      hsa_agent_get_info(agent, HSA_AGENT_INFO_DEVICE, &type);
  if (status == HSA_STATUS_SUCCESS && type == HSA_DEVICE_TYPE_GPU)
    *static_cast<hsa_agent_t *>(data) = agent;
  return status;
}

__attribute__((destructor)) void CheckLateWrites() {
  if (writes->overlaps.load() != 0) {
    std::fprintf(
        stderr, "Queue event destroyed during an outstanding callback write\n");
    std::_Exit(1);
  }
}
} // namespace

extern "C" int ioctl(int fd, unsigned long request, ...) {
  va_list args;
  va_start(args, request);
  void *argument = va_arg(args, void *);
  va_end(args);
  static const auto next =
      reinterpret_cast<int (*)(int, unsigned long, void *)>(
          dlsym(RTLD_NEXT, "ioctl"));
  if (next == nullptr)
    std::_Exit(1);

  // KFD SET_EVENT (0x4b0a) and DESTROY_EVENT (0x4b09) both start with
  // uint32_t event_id. Ignore the size/direction bits in the ioctl number.
  const bool delayed = (request & 0xffff) == 0x4b0a && argument != nullptr &&
                       !pthread_equal(pthread_self(), writes->main_thread);
  const bool destroyed = (request & 0xffff) == 0x4b09 && argument != nullptr;
  const uint32_t id =
      delayed || destroyed ? *static_cast<uint32_t *>(argument) : 0;
  if (delayed) {
    {
      std::lock_guard<std::mutex> lock(writes->mutex);
      ++writes->pending[id];
    }
    ++writes->delays;
    // Allow native queue destruction to progress before this callback's final
    // write completes. Forward the real ioctl unchanged after the delay.
    usleep(delay_us);
  }
  if (destroyed) {
    std::lock_guard<std::mutex> lock(writes->mutex);
    if (writes->pending[id] != 0)
      ++writes->overlaps;
  }
  const int result = next(fd, request, argument);
  const int saved_errno = errno;
  if (delayed && result != 0)
    std::fprintf(stderr,
                 "Delayed KFD SET_EVENT id=%u failed: result=%d errno=%d\n", id,
                 result, saved_errno);
  if (delayed) {
    std::lock_guard<std::mutex> lock(writes->mutex);
    --writes->pending[id];
  }
  errno = saved_errno;
  return result;
}

int main(int argc, char **argv) {
  if (argc == 2)
    delay_us = static_cast<unsigned>(std::strtoul(argv[1], nullptr, 10));
  if (hsa_init() != HSA_STATUS_SUCCESS)
    return 1;
  hsa_agent_t gpu{};
  if (hsa_iterate_agents(FindGpu, &gpu) != HSA_STATUS_SUCCESS)
    return 1;
  if (gpu.handle == 0) {
    hsa_shut_down();
    std::fprintf(stderr, "No GPU agent; physical KFD GPU required\n");
    return 77;
  }
  char name[64]{};
  hsa_agent_get_info(gpu, HSA_AGENT_INFO_NAME, name);
  std::fprintf(stderr, "GPU=%s; callback delay=%u us\n", name, delay_us);
  for (unsigned iteration = 0; iteration != 1; ++iteration) {
    hsa_queue_t *queue = nullptr;
    if (hsa_queue_create(gpu, 64, HSA_QUEUE_TYPE_MULTI, nullptr, nullptr, 0, 0,
                         &queue) != HSA_STATUS_SUCCESS)
      return 1;
    if (hsa_queue_destroy(queue) != HSA_STATUS_SUCCESS)
      return 1;
  }
  if (hsa_shut_down() != HSA_STATUS_SUCCESS)
    return 1;
  std::fprintf(stderr, "hsa_queue_create, hsa_queue_destroy, hsa_shut_down all "
                       "returned SUCCESS\n");
  std::fprintf(
      stderr,
      "Queue event lifetime: delayed writes=%u, overlapping destroys=%u\n",
      writes->delays.load(), writes->overlaps.load());
  if (writes->overlaps.load() != 0)
    return 1;
  if (writes->delays.load() == 0) {
    std::fprintf(stderr, "No background KFD event writes exercised\n");
    return 77;
  }
  return 0;
}
```

</details>
