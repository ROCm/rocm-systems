// Copyright Advanced Micro Devices, Inc., or its affiliates.
// SPDX-License-Identifier: MIT
#include <cstdarg>
#include <cstdint>
#include <dlfcn.h>
#include <execinfo.h>
#include <cstdio>
#include <cstring>
#include <unistd.h>
extern "C" int ioctl(int fd, unsigned long req, ...) {
  va_list ap; va_start(ap, req); void* arg=va_arg(ap,void*); va_end(ap);
  static auto next=reinterpret_cast<int(*)(int,unsigned long,void*)>(dlsym(RTLD_NEXT,"ioctl"));
  if ((req & 0xffff)==0x4b0a && arg) {
    void* frames[12]; int n=backtrace(frames,12);
    for(int i=0;i<n;i++) {
      Dl_info info{};
      if(dladdr(frames[i],&info) && info.dli_fname && std::strstr(info.dli_fname,"libhsa-runtime64") && reinterpret_cast<uintptr_t>(frames[i])-reinterpret_cast<uintptr_t>(info.dli_fbase)>=0x5a420 && reinterpret_cast<uintptr_t>(frames[i])-reinterpret_cast<uintptr_t>(info.dli_fbase)<0x5a96b) {
        std::fprintf(stderr,"[diagnostic] delaying queue callback SET_EVENT id=%u runtime=%s offset=%lx\n",*static_cast<uint32_t*>(arg),info.dli_fname,reinterpret_cast<uintptr_t>(frames[i])-reinterpret_cast<uintptr_t>(info.dli_fbase));
        usleep(1000);break;
      }
    }
  }
  if ((req & 0xffff)==0x4b09 && arg && *static_cast<uint32_t*>(arg)==6) {
    std::fprintf(stderr,"[diagnostic] DESTROY event6\n");
  }
  int r=next(fd,req,arg);
  if ((req & 0xffff)==0x4b0a && arg && *static_cast<uint32_t*>(arg)==6 && r) {
    std::fprintf(stderr,"[diagnostic] failed event6 SET backtrace\n");
    void* frames[14]; int n=backtrace(frames,14);backtrace_symbols_fd(frames,n,2);
  }
  return r;
}
