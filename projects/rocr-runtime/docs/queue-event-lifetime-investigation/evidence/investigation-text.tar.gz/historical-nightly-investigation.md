# First nightly gfx942 solution race sample

Date: 2026-10-15
Toga/agent: toga-6-shark52 / Codex
Repository revision: #13687 `0b00f973a8192236085eb6e53bd0ff9a6fa74e07`; fetched develop `ce535279bcdf0bd11d9eb01fed8ea4387f48c4d8`
Related PR/issue: [Libraries #13687](https://github.com/ROCm/rocm-libraries/pull/13687), #12734, #13520, #13412; AIHPBLAS-3605
Outcome: complete investigation; nightly implementation and qualification remain outstanding

The first step is feasible with existing CI infrastructure. Reuse the scheduled multi-arch nightly and its gfx942 artifacts, execute on the CPU build pool, and use a fixed-seed ordered prefix of solution entries. #13687 supplies the one-problem API, while #12734 supplies the inventory, worker queue, execution checks and reports. Several integration fixes are needed before this combination is ready. No production source changes or external writes were made in this investigation.

## Live PR map

| Work | State checked October 15 | Role |
| --- | --- | --- |
| [Libraries #13687](https://github.com/ROCm/rocm-libraries/pull/13687) | Draft/open, `0b00f973a819` | One full output tile, K=8×DepthU×fixed split; validation-only bench adapter; zero timed launches |
| [Libraries #13520](https://github.com/ROCm/rocm-libraries/pull/13520) | Open/non-draft, `d53f382904f4` | Shared binary metadata/datatype reader; #13687 includes an earlier prerequisite revision |
| [Libraries #12734](https://github.com/ROCm/rocm-libraries/pull/12734) | Draft/open, `6c700bce1bd6`, conflicts with develop | Fixed-seed solution sampling, two clients, workers/timeouts, installed campaign tool, honest coverage accounting |
| [Libraries #13412](https://github.com/ROCm/rocm-libraries/pull/13412) | Draft/open, `6cc695469b39` | Earlier multiple-candidate generator; useful reference, unnecessary dependency for one-problem pilot |
| [Libraries #13516](https://github.com/ROCm/rocm-libraries/pull/13516) | Merged | gfx950 MX scale allocation; relevant when MX coverage is added |
| [Systems #12963](https://github.com/ROCm/rocm-systems/pull/12963) | Merged October 14, merge `c2bffdf7c653` | Scalar atomic decrement support; old sampled job's 26-kernel skip list needs reassessment |
| [Systems #12964](https://github.com/ROCm/rocm-systems/pull/12964) | Open, `db5793945acd` | Prompt failure instead of native-client timeout on fatal unsupported instructions |

Earlier CI work matters: [#9363](https://github.com/ROCm/rocm-libraries/pull/9363) established CPU-side execution and same-run artifact consumption; merged [#9969](https://github.com/ROCm/rocm-libraries/pull/9969) relanded it with advisory failures and deliberately excluded nightlies. Merged [#10504](https://github.com/ROCm/rocm-libraries/pull/10504) further restricted direct PR triggers. Merged [#11436](https://github.com/ROCm/rocm-libraries/pull/11436) enabled modern plugins and required observed dispatch/MFMA work; merged [#12425](https://github.com/ROCm/rocm-libraries/pull/12425) repaired missing test dependencies. Closed/unmerged [#10543](https://github.com/ROCm/rocm-libraries/pull/10543) proved GitHub-hosted CPU runners technically work, but its historical source build took about 14–16 minutes. TheRock #6517/#6525/#6575 are closed unmerged; do not assume those old packaging proposals shipped.

## Exact nightly integration point

Use `.github/workflows/therock-multi-arch-ci-nightly.yml`, named **TheRock Multi-Arch Nightly CI**. It already has `schedule: cron: "0 7 * * *"` and `workflow_dispatch`, and scheduled runs target the repository's default `develop` branch. That is midnight PDT / 23:00 PST on the previous local calendar date. `.github/workflows/therock-ci-nightly.yml` is a separate dispatch-only workflow despite its name.

The actual nightly currently builds Linux gfx94X/gfx950/gfx125X and Windows gfx1151, but contains no race job. The PR-side caller in `therock-multi-arch-ci.yml` explicitly requires `github.event_name == 'pull_request'`, so landing #12734 or #13687 alone does not enable nightly execution. Add a distinct nightly caller of `therock-rocjitsu-race-check-linux.yml`; keep the existing PR selector. A reviewable, non-production [complete YAML sketch](<TOGA_ROOT>/scratch/gfx942-nightly-investigation-20261015/nightly-workflow-sketch.yml) illustrates the call.

The call uses `amdgpu_families: gfx94X-dcgpu`, `amdgpu_targets: gfx942`, the locked `needs.setup.outputs.ref` for TheRock, and `aws-linux-scale-rocm-prod` from the CI environment action. The race workflow retrieves `--blas --tests` using the current `github.run_id`, then uses the matching HIP/HSA runtime, native bench, library metadata and code objects. No GPU runner or device passthrough is needed for execution. Changing to gfx950 later means the gfx950 artifact group, target-specific emulator configuration and hardware-predicate coverage, not provision of an MI350 worker.

The easiest dependency is `needs: [setup, linux_build_and_test]`, with `!cancelled()` and an explicit non-skipped producer condition. This allows the race job to attempt artifact retrieval even if unrelated GPU tests failed; requiring overall Linux success would suppress useful race runs. Missing/broken required artifacts must still fail visibly. **It still waits for all jobs in that reusable Linux workflow, including queued GPU tests.** GitHub cannot depend directly on a nested math-library producer job. Starting as soon as BLAS artifacts publish requires a separate producer/dependency interface in TheRock, or a carefully designed artifact-ready mechanism. This is a follow-up, not needed to prove the first nightly call.

The historical #12734 [successful CI race job](https://github.com/ROCm/rocm-libraries/actions/runs/37705136135/job/113181823235) used this CPU runner, took 9m25s excluding upstream/queue time, and independently recorded 352 passed/48 skipped out of 400 cases through each client. It used four cases per solution and two target bench launches per case, so it is not evidence for the proposed new policy's runtime. Its detailed receipts remain in [the canonical handoff](260929_pr12734_rocjitsu_sampled_sweep_handoff.md#october-8-report-links-and-job-timing).

Live nightly observations: [October 14 run](https://github.com/ROCm/rocm-libraries/actions/runs/38527180317) failed overall but its gfx942 and gfx950 math-library producers passed. [October 15 scheduled run](https://github.com/ROCm/rocm-libraries/actions/runs/38697600236) was still queued at investigation closeout. No new CI run was dispatched.

## Proposed initial campaign

Start at 100 solution entries, fixed selection seed `0`, four worker processes, one #13687 descriptor per solution with `reduction_blocks=8`. A 20-entry invocation is useful for the first qualification smoke; raising the count should extend the same ordering. Select every eligible solution record individually, retaining aliases sharing names/kernels. Rank by SHA256(seed+NUL+solution name), then full canonical execution/configuration metadata with index/performance-only fields excluded; index is only the final tie-breaker. Do not seed from the date or commit SHA, sort solely by index, deduplicate by kernel, or replace failed/skipped selected entries. Changes to the eligible library inventory can still change the prefix; preserve input hashes and the actual plan.

Keep hardware compatibility explicit. The emulator has a simulated PCI ID/CU count: lack of physical hardware does not make every hardware predicate true. Unsupported/unknown device profiles remain counted gaps. Later all-gfx950 work may need several virtual device profiles.

For each selected entry, produce `get_problem(index)` and `bench_yaml([problem])`. Convert with the campaign's own Python plus the matching shipped `hipblaslt_gentest.py` and `hipblaslt_template.yaml`, then run bench `--data`. #13687's integration tests already use this path because bench's build-selected Python can lack PyYAML in CI. Use matching native client and helper versions; an old bench still turns zero timing iterations into an extra launch.

Preserve #12734's independent TensileLite stage while integrating the regular bench path. #13687 currently exposes only a bench adapter. Applying exactly the same regular descriptor to TensileLite requires a small INI/client-options adapter and independent qualification; it is not supplied by #13687. The quickest nightly milestone can retain the existing four-case Tensile stage while adopting the one-case bench stage, with both policies explicitly named in reports. A later shared-descriptor adapter avoids maintaining divergent size policy.

Use bounded processes and explicit per-process/stage timeouts (existing 120s/1500s are sensible starting limits), a shared assignment queue, single-core emulator budgets/affinity, and OMP/OpenBLAS/MKL threads=1. Retain commands, YAML/data, metadata/tool/code-object hashes, numerical rows, selected index/name/kernel, target and helper dispatch counts, stderr/race reports, timings, and all selected-case outcomes. A successful regular bench case requires one target dispatch, native numerical checks and exact identity, no detector reports/warnings, and successful process exit. Initialization and split-reduction helpers may launch separately and must remain inspected.

Expected generator/adapter exclusions receive no coverage credit. Malformed metadata/unexpected exceptions, native rejection of an intended supported problem, timeout, missing result, wrong dispatch, numerical failure or race remain visible failures. Fail fast on unexpected execution failure while accounting for in-flight and unstarted cases. An empty campaign must fail. Do not blanket-ignore helper races. The existing known-failure list is tied to the old detector and `tile-depth-v1` cases; updating the detector or using regular cases requires explicit reassessment, not copying the list unchanged.

Existing race CI is advisory (`continue-on-error: true`) and excluded from the required summary. A first nightly burn-in can retain that policy, with its report clearly showing actual failure/skips. Decide separately whether the nightly summary should require the check; adding it to `needs` while leaving job-level advisory behavior does not by itself establish a reliable failure gate. No notification or publishing workflow was introduced here.

## Fresh local evidence and implementation findings

The reproducible [investigation directory](<TOGA_ROOT>/scratch/gfx942-nightly-investigation-20261015) contains the published runner extracts, scan/probe scripts, a 100-entry plan, input/tool hashes, execution commands and logs. This uses retained production gfx942 artifacts from CI37396020736, the current #13687 Python source, a retained native bench incrementally rebuilt for #13687 review fixes, and rocJITsu snapshot `29656a8dcc052615e1ca49cafde98d684b6b81f2`. It is not a current-nightly artifact test or a full 100-entry execution.

The scan examines 352,033 records: 240,606 match the configured virtual device; 111,427 have other/unknown hardware. Among matching records, 158,215 raise declared unsupported-feature exceptions, **35,620 instead raise `ValueError: invalid globalSplitU 0`**, and 46,771 construct a descriptor and bench input. All 35,620 errors are Stream-K records. Current source also explains that GSU0 is valid for persistent scheduling. #13687 checks the split value before collecting its deferred scheduling reasons, so a campaign that correctly aborts on malformed input would stop immediately. Fix the classification order: valid deferred Stream-K/GSU0 should become `UnsupportedSolution`, while invalid ordinary GSU0 remains an input error. The investigation continues after errors only to inventory them; a production runner must not adopt that diagnostic continuation as a skip policy.

The streamed scanner plus 100-entry heap took about 20 seconds and 251 MiB maximum RSS. It reuses #13520's per-shard reader and invokes descriptors on transient one-record `LibraryMetadata`; this is an investigation technique, not a public adapter proposal. `load_library_metadata(..., solution_indices=None)` retains the full inventory; selective loading still scans/decompresses every shard. A production campaign should stream selection once and retain only selected records, avoiding a second full scan per solution or an unnecessary all-record retention. Bounded subset checks confirm the priority matches published #12734, traversal shuffle does not change the order, renumbering preserves selected names, and 20 is a prefix of 100.

Ten production-kernel probes were executed: the first eight entries and one example of each complex precision. **Nine pass** numerical checks, exact solution/kernel identity and exactly one target dispatch, with no race reports/warnings. FP32, FNuz FP8/BF8, mixed FP8/FP16, complex FP32 and complex FP64 all appear in these probes. The tenth, index315754, dispatched and then timed out at120s on unsupported `s_atomic_dec` in the retained emulator. Qualify a pinned Systems revision containing merged #12963; #12964 remains useful for prompt unrelated unsupported failures but is not required to make atomic decrement execute. Old and weakened-wait controls should remain part of pin qualification.

The two complex probes initially appeared missing because bench prints unquoted `(real,imag)` alpha/beta fields into its CSV output. Quoting those parenthesized scalar fields before CSV parsing recovers one numerical row with norm_error0 each. A straightforward reuse of #12734's `csv.reader` parser would reject them. Keep complex validation parsable or report it explicitly; do not infer success from process exit alone.

Successful process wall times were1.54–7.56s with peak RSS0.70–2.47GiB. Four jobs were orchestrated concurrently, but these exploratory runs were not pinned to four physical cores, so this is not CI throughput or aggregate-memory evidence. The sample's largest K is45,056 due to fixed split22×DepthU256×eight blocks. One output tile does not guarantee a cheap process. Preserve process/stage limits, report resource limits honestly, and measure the whole sample before declaring its nightly budget.

An attempted `--host_side_fill_kernel` against #13687's bench failed immediately: that flag is added by #12734, not #13687. Successful probes used current device initialization. Integrating #12734 retains its faster host initialization option; ensure policy/replay records which initializer was used.

## Suggested implementation sequence

1. Fix #13687's valid deferred GSU0 classification, synchronize its metadata prerequisite as appropriate, and retain one-dispatch/installed-artifact tests.
2. Reconcile #12734 with develop and adopt the regular bench descriptor, active-interpreter data conversion, complex-row parsing, and streamed selection. Preserve both client stages and all accounting. Qualify a new detector pin containing #12963 and reassess every old skip under its actual case policy.
3. Add the nightly caller without a second cron; run a manual20-entry artifact smoke followed by the deterministic100-entry campaign, inspect reports even if the job is advisory, and verify a race-producing negative control still fails the tool. Then observe an actual scheduled develop run.
4. Measure whole-stage runtime/RSS and producer/queue delays. Later improvements are packaged rocJITsu, earlier artifact-ready scheduling, compatible multi-solution process batching, virtual device-profile coverage, gfx950 target selection, and deferred scheduling/MX/edge/tail/epilogue paths.

Executing every solution index and exercising every race-relevant path are separate milestones. The present API is a baseline for supported fixed-split solutions, not yet complete gfx950 coverage. The [prior gfx950 capacity study](260928_gfx950_nightly_race_sweep_capacity.md) has useful loading/batching evidence, but its old full-library arithmetic is not a runtime forecast for this policy.

## October 15 implementation and local qualification

Date: 2026-10-15
Toga/agent: toga-6-shark52
Repository revision: 5bce6252d66e653704625bccbded1be4876cc0c5 (integration branch); develop b798b7357dad7f950c8cc99ab9fa77711146947c
Related PR/issue: Libraries #13687, #12734; AIHPBLAS-3605
Outcome: implementation, local qualification and authorized publication complete; actual nightly qualification pending

User authorized proceeding after the investigation. Preserved #13687 on its actual head branch with classification fix `657e79212d2` (two regressions failed before; all80 descriptor tests now pass). Created `users/jnewling/AIHPBLAS-3605-nightly-gfx942`, merged #12734 and current develop, then committed the nightly integration as `5bce6252d66`. No network write, PR edit or workflow dispatch.

The scheduled nightly now calls the existing CPU race workflow with same-run gfx94X-dcgpu/gfx942 artifacts. It waits for the whole Linux reusable workflow, attempts artifact consumption despite unrelated GPU failures, excludes skipped producers/cancellation, and remains advisory. Bench uses regular-v1/seed0/100 entries/four workers; TensileLite retains independent tile-depth-v1. Streamed legacy/indexed metadata retains aliases and reports unsupported reasons; malformed data aborts. Bench uses matching shipped gentest/template plus active Python outside emulation, host input initialization, exact identity/numerical/one-dispatch checks, and no warning suppression. Policy-specific exclusion files are both empty after requalification.

Qualification uses newly built integrated native clients and a fresh detector from merged Systems #12963 (`c2bffdf7c6530c79329edd0add31fa9d0485b96f`), with retained production gfx942 artifacts from CI37396020736. No GPU is needed. Source100-entry bench passed100/100 with no skips/warnings/races,185.49s including22.01s preparation. Final installed20-entry smoke passed20/20 in54.30s. Production inventory:352033 total,46771 eligible,193835 expected unsupported,111427 other/unknown hardware. All35620 StreamK/GSU0 records now count as unsupported rather than errors. Selected100 entries include97 distinct kernels; no deduplication/replacement.

All26 old s_atomic_dec kernel exclusions were found and one index for each ran all four historical cases:104/104 passes, no warnings/races. Two original-wait controls passed; three byte-local weakened-wait controls retained numerical success and each reported a race plus memory-wait warnings. Source/installed sampler37 tests and orchestration6 tests pass;166 focused descriptor/metadata tests,150 installed descriptor/reader tests, and22 native benchmark timing tests pass. Native bench/TensileLite/rocisa build and tests install pass. Root pre-commit (full branch diff), component Bandit/affected-test hook, Black/flake8, actionlint, shellcheck and git diff checks pass. C++ changed-line git-clang-format reports no changes; whole-file formatting debt exists on unchanged develop too.

Burn-in findings remain visible: independent TensileLite sample emits intermittent SET_EVENT_MISS event_id6 warnings with numerical/dispatch success. One full run stopped after304 numerical passes and96 unstarted cases; a prior run warned at another index, and the isolated index recheck passed. No warning or solution skip was added. A regular100 run also received unexplained SIGTERM early; preserved that failed run, while the subsequent100 and installed20 completed. Do not call the entire two-client CI job reliably green yet. The broader unit suite ran10394 passes,135 failures,14 errors,611 skips; every149 failing node reproduced on an untouched develop snapshot in the same environment. No new failing node or golden update. These failures are unrelated codegen characterization/corpus debt, not evidence of the nightly adapter breaking codegen.

Artifacts: [implementation receipts](<TOGA_ROOT>/scratch/gfx942-nightly-implementation), especially validation-receipt.json, regular-production-plan.json, bench-100-final/summary.md, installed-bench-final-smoke/summary.md, atomic-recheck/, wait-controls/, unit-suite-baseline.log, root-precommit-exact-head.log and proposed pr-description.md/pr-title.txt. Builds and Python environment are under this toga's builds/rocm-libraries/nightly-gfx942-* and venvs/nightly-gfx942. Fresh Python dependencies/rocisa and lint tools were installed only in that task environment.

Next: review draft integration PR #13781; validate artifact fetch/layout and scheduler in an actual manual nightly run if authorized, then observe scheduled develop after landing. Diagnose SET_EVENT_MISS in Systems before removing advisory status. Preserve the existing dependency PRs; this integration contains both draft series and should be split/stacked or merged only after prerequisite review. Eventual all-gfx950 still needs virtual device profiles, deferred StreamK/automatic-split/MX coverage and additional edge/epilogue cases. Source worktrees return to toga-6-shark52 home branches with all task commits preserved.


## October 15 authorized publication

Date: 2026-10-15
Toga/agent: toga-6-shark52
Repository revision: 5bce6252d66e653704625bccbded1be4876cc0c5; latest develop c37a44e1881bdcf85509888c152e0633dbd43e27
Related PR/issue: [Libraries #13781](https://github.com/ROCm/rocm-libraries/pull/13781); AIHPBLAS-3605
Outcome: authorized push and draft PR creation complete; actual nightly execution pending

User explicitly approved pushing the prepared branch and creating its draft PR. Published `users/jnewling/AIHPBLAS-3605-nightly-gfx942` at the exact validated head and created draft #13781 against develop. Verified draft flag, head, body and mergeability. Fresh develop had three additional CK/docs commits with no task-file overlap; merge-tree check was clean, so the validated branch was preserved without rebase or merge.

Initial publication CI snapshot: no failed checks. Pre-commit and the PR bot running; TheRock multi-arch Windows/Linux staging, hipBLASLt ASAN and TensileLite coverage queued. Base freshness, labeling and other completed setup/gate workflows passed; gated lanes were skipped where configured. This is an initial snapshot, not completed build qualification. Detailed workflow/job states are in [publication-receipt.json](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/publication-receipt.json).

No manual nightly workflow dispatch, review, comment or merge was performed. Same-run artifact retrieval and actual scheduled execution remain unqualified; intermittent independent TensileLite SET_EVENT_MISS warnings still need investigation before removing advisory status. Integration retains the dependency series and needs prerequisite review/splitting before landing. All source worktrees remain on home `toga-6-shark52`; Libraries/Systems clean, Baritone's two preexisting untracked notes preserved.


## 2026-10-15 — manual nightly and ROCr queue event diagnosis

Date: 2026-10-15
Toga/agent: toga-6-shark52
Repository revision: Libraries `5bce6252d66e653704625bccbded1be4876cc0c5`; Systems candidate `d68cd7890a2403d3527bb575309d09a5982c97f6`, base `5ae2d3fcc39d8b8e750d9fc031277362313d71dc`
Related PR/issue: [Libraries #13781](https://github.com/ROCm/rocm-libraries/pull/13781), #13687, #12734; AIHPBLAS-3605
Outcome: authorized nightly dispatched; runtime fix validated and committed locally; CI artifact qualification and runtime publication pending

User authorized the recommended next steps with “Please proceed.” Dispatched [nightly run 38809773834](https://github.com/ROCm/rocm-libraries/actions/runs/38809773834) on the exact published integration head at 21:25 UTC. Latest snapshot: Linux compiler/runtime and emulation stages passed; gfx942 math producer queued; no failed nightly jobs, race consumer not started. Same-run artifact retrieval remains unqualified and this workflow waits for the whole Linux reusable workflow including GPU tests. No implication that a GPU is needed by the race job itself. The earlier PR run 38808576243 was cancelled before math artifacts and its summary failed; emulation logs show broad CTest crashes and container runner failure. A replacement PR run is active on the same head; pre-commit/PR bot/ASAN summaries passed, other lanes pending. Cancellation cause is unestablished. No additional dispatch, comment, review or merge.

Intermittent `SET_EVENT_MISS` was reproduced without GEMM: hsa_init, enumerate GPU, create/destroy64 queues, hsa_shut_down. The ROCr exception callback publishes DONE and its signal value before its final hsaKmtSetEvent finishes. Async runtime retains the signal, but the queue's shared event was a borrowed raw pointer. The final queue destructor could destroy that event while the retained callback still wrote it. Ordinary replays often pass (16 concurrent GEMM replays,64 numerical cases), so successful isolated reruns were inadequate evidence. A1ms delay before callback SET_EVENT reproduces the original event6 GEMM warning and event5 queue-only warning in3/3 runs each.

Systems branch `users/jnewling/AIHPBLAS-3605-queue-event-lifetime` at `d68cd7890a2403d3527bb575309d09a5982c97f6` makes queue signals retain shared event ownership. Last queue release resets the holder; actual event deletion occurs when retained signals finish. The holder survives static teardown like the existing queue lock/count. A normal function-local shared_ptr was insufficient: HIP releases queues during late library shutdown, after that holder's destruction. The tiny holder remains process lifetime; the event itself still releases. Raw borrowed constructors for other event users remain. Null CreateEvent is checked before attaching the deleter; no warning suppression or Libraries pin change.

Added rocrtst queue_event_lifetime_test, also independently buildable against installed ROCr. It interposes on public KFD ioctl requests and delays background event writes without private symbols. It detects DESTROY_EVENT overlapping a pending write; no dispatches. It returns skip77 if no GPU/background event path executes. Delay is stress amplification, not deterministic scheduling. Original runtime fails3/3 with130 delayed writes/one overlapping destruction and SET_EVENT_MISS; candidate passes3/3 with130 delays/no overlaps. Final exact-tree rebuild and3 regression runs plus4-case GEMM smoke pass. Previously failing GEMM shutdown with the private-callback delay passed3/3; those receipts count actual injected delays.

Broader candidate validation: Tensile100 solutions/400 cases all PASS,141.04s execution/154.12s with preparation; installed regular bench20/20 PASS,52.25s total. No skips/missing/unstarted cases or warnings. Full rocrtst suite and physical GPU were not built/exercised; standalone regression target was. New test formatting hooks pass. Root hooks were run on all8 changed files: existing runtime files have whole-file clang-format debt and existing suite CMake has trailing whitespace/gersemi debt, reproduced on untouched base. Restored unrelated formatter churn and formatted changed C++ lines; git diff --check passes. Exact logs and base comparison preserved; do not call whole-file hooks green.

[Diagnosis, commands, build logs and validation receipt](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis), [Tensile full report](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/tensile-100-fixed-runtime/summary.md), [installed bench report](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/installed-bench-fixed-runtime/summary.md). Prepared portable runtime [draft body](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/pr-description.md) and title locally. Fresh Systems develop has two non-overlapping commits; merge-tree clean, validated candidate left unchanged. Next: publish runtime draft with user authorization, qualify nightly artifact consumer when producer completes, then prerequisite review/splitting/landing for nightly integration. Candidate runtime is not used by the current dispatched CI. Do not remove advisory status until fixed-runtime CI and burn-in qualify. All source worktrees returned to home; task commits preserved, Baritone's unrelated notes untouched. No active CI monitor after this handoff.


## 2026-10-16 — runtime draft published; nightly race artifact consumer qualified

Date: 2026-10-16
Toga/agent: toga-6-shark52
Repository revision: Systems `d68cd7890a2403d3527bb575309d09a5982c97f6`; Libraries `5bce6252d66e653704625bccbded1be4876cc0c5`
Related PR/issue: [Systems #13635](https://github.com/ROCm/rocm-systems/pull/13635), Libraries #13781; AIHPBLAS-3605
Outcome: authorized runtime push/draft creation complete; manual nightly artifact/CPU path qualified; prerequisite landing and scheduled develop/fixed-runtime CI pending

User approved the prepared runtime publication. Pushed the exact validated head and created draft Systems #13635 against develop. Remote head, draft flag, body and mergeability verified. Sixteen newer develop commits have no changed-file overlap; merge-tree clean; no rebase or source changes. CI snapshot:18 success,24 skipped,3 queued,2 running,1 cancelled,1 failure. Failed multi-arch summary follows cancelled setup in run38921785108, not a completed runtime build failure. Cancellation cause unestablished; no CI action/extra write taken. Publication does not establish CI completion.

Manual nightly38809773834 is complete overall failure, latest run_attempt4 (retries not initiated here). The CPU [nightly race job](https://github.com/ROCm/rocm-libraries/actions/runs/38809773834/job/116987988330) passed with every step successful, including environment/artifact setup, race execution, result publication and report upload. Downloaded the latest report artifact12048667291: bench regular-v1 seed0 100 solutions/100 cases all pass (191.32s); Tensile tile-depth-v1 seed0 100 solutions/400 cases all pass (167.80s). Both fully_validated=true, zero warning entries, no skips/missing/unstarted. Four CPU workers; detector revision recorded in manifests. Emulator build368s; race job approximately13min total. gfx942 math producer succeeded. This qualifies the real nightly same-run artifact fetch/layout and CPU execution path, though no scheduled develop run has happened with the change. Original runtime happened to pass; this does not invalidate the controlled intermittent queue-event reproducer or qualify the new runtime in CI.

Other nightly test lanes failed, including gfx125X sanity/Python, Windows HIP/rocSPARSE and gfx94X TensileLite-common; these are separate from the passing race job. Paginated job API intermittently returned502; preserved successful pages and selected outcomes, not a claim of complete root-cause triage for every other lane. gh run --job --log returned empty, so counts are established by job steps plus downloaded JSON reports. Full report input hashes/selection/tools retained.

[Runtime publication receipt](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/publication-receipt.json), [runtime live PR snapshot](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/pr-published.json), [nightly qualification receipt](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/nightly-ci-current.json), [downloaded bench summary](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/nightly-race-reports/sweep-bench/summary.md), [Tensile summary](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/nightly-race-reports/sweep-tensile/summary.md). Next: review/land runtime and Libraries prerequisite series, qualify fixed-runtime CI and observe scheduled develop after landing; retain advisory policy until burn-in. All source worktrees home, unrelated Baritone notes preserved. No comments, reviews, merges or ongoing CI monitor.


## 2026-10-16 — physical-hardware reproducer without rocJITsu

Date: 2026-10-16
Toga/agent: toga-6-shark52
Repository revision: Systems draft #13635 `d68cd7890a2403d3527bb575309d09a5982c97f6` (unchanged)
Related PR/issue: Systems #13635; AIHPBLAS-3605
Outcome: native reproducer verified on gfx1201 and gfx942; source/logs packaged locally

User asked for a reproducer not using rocJITsu. Checked-in 1ms/64-queue test ran on physical Shark52 gfx1201 but did not reproduce in initial or12 pinned-core runs;10/50/100/150us across48 runs also passed. Callbacks were verified in GDB. A100ms background SET_EVENT delay, reduced to4 queue creations, reproduces native event lifetime violation. No extra handshake is needed. Standalone source includes HSA queue init/create/destroy/shutdown plus ioctl interposition, forwards actual KFD requests unchanged, prints real SET_EVENT EINVAL and detects outstanding-write/destroy overlap. Does not load rocJITsu, HIP, GEMM or dispatch kernels. Injected timing, not a natural crash reproduction.

Final source queue-event-repro.cpp: Shark52 gfx1201 old artifact ROCr1.21.0 fails3/3 with KFD SET_EVENT id3 returning-1/errno22,10 delayed writes and1 overlap; fixed runtime passes3/3 with10 delays/zero overlaps. Observed /proc process library mappings prove no rocJITsu loaded; exact runtime file digests and environments retained. Approved SharkMi300X4 worker: physical gfx942, installed ROCm7.2.1, same source fails3/3 with SET_EVENT EINVAL/15 delays/one overlap. Fixed runtime not built on MI300 worker. Original1ms test on MI300 passed5/5 before amplification. No native unmodified-timing failure claimed. Published PR regression/description not modified in this step; candidate test should adopt/parameterize native delay before claiming reliable native regression coverage.

[Standalone source](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/native/queue-event-repro.cpp), [build/run instructions](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/native/README.md), [local receipt with mappings/digests](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/native/reproducer-receipt.json), [MI300 environment](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/native/mi300x-environment.log) and repro-1..3.log. Worker execution-only artifacts: SharkMi300X4 `~/workspace/results/rocm-systems-toga-6-shark52-queue-event-native`. Existing task note remains canonical. Source branch unchanged; all worktrees home at handoff, unrelated Baritone files preserved. No push/PR edit/comment/review/merge.


## 2026-10-16 — current develop confirmed, issue prepared locally only

Date: 2026-10-16
Toga/agent: toga-6-shark52
Repository revision: unmodified Systems develop `6191d1527b29369b6558ff7cc246281704e22224`
Related PR/issue: Systems draft #13635; AIHPBLAS-3605
Outcome: current-develop native failure confirmed; explanation/reproducer/issue draft prepared, no issue creation authorized

User prefers establishing the issue on current develop and reporting it to ROCr maintainers rather than owning a runtime implementation. Explicit steering: “Don't create an issue until I say so.” No issue created; draft PR unchanged. Fresh branch users/jnewling/AIHPBLAS-3605-develop-reproducer tracks origin/develop at `6191d1527b29369b6558ff7cc246281704e22224`; no source modifications. Fresh Release runtime built with host Clang23.1.0, retained ROCm clang24 for support kernels using previously documented task-only CMake import shims. Matching current thunk compiled into runtime; maps identify new runtime. Full build/configuration and hashes preserved.

Reproducer compiled with amdclang++20/installed ROCm7.1. Four-queue variant fails5/5 natively on gfx1201. Reduced to one application queue; zero queues exercises no callbacks (skip77). One-queue adjustable-delay final source:100ms fails5/5, zero-delay passes5/5; repeat against same-develop headers fails3/3/passes3/3. All public HSA create/destroy/shutdown calls return SUCCESS even during failure. Real KFD SET_EVENT returns EINVAL after successful event destruction; instrumentation detects one overlapping destroy. Native strace confirms syscall ordering. No natural-timing native crash or numerical corruption claim.

More precise root cause from current native stacks: delayed write is from DynamicQueueEventsHandler<false>/queue-inactive callback, not the exception callback. The exception path has analogous source ordering and historical emulated evidence, but do not label the traced current native failure ExceptionHandler. Destruction stack is hsa_shut_down → Runtime::Unload → GpuAgent::ReleaseResources → AqlQueue::~AqlQueue, after user queue already destroyed, while releasing final internal queue. Callback publishes DONE then stores signal value; store writes value before event notification. Destructor can observe completion and destroy shared raw-borrowed event while async loop retains the signal until callback return. Issue can report verified event lifetime violation and leave fix design to maintainers. Potential earlier raw-pointer use-after-free is plausible, not separately proven native crash.

[Current-develop artifacts/source/issue draft](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/develop), specifically issue-draft.md, queue-event-repro.cpp, verification-receipt.json, trace.log, native-strace.log, minimal-final-results.json/current-headers-results.json. Issue draft self-contained, source in expandable block, portable commands/source revision/limits. Duplicate search returned separate async-exit/busy-poll issues, no exact match, not exhaustive. Earlier draft fix/current CI unchanged and no additional publication. Worktrees home at closeout; source/build branch preserved, no active local jobs.


## 2026-10-16 — simpler public-HSA reproducer with separate timing helper

Date: 2026-10-16
Toga/agent: toga-6-shark52 / Codex
Repository revision: unmodified Systems develop `6191d1527b29369b6558ff7cc246281704e22224`
Related PR/issue: Systems draft #13635; AIHPBLAS-3605
Outcome: user's reproducer simplicity/validity concern addressed locally; no network writes

Split the previous combined reproducer into a 46-line public-HSA queue lifecycle program and a separate 53-line LD_PRELOAD timing helper. Workload queries the agent's queue size/type, passes documented UINT32_MAX unspecified segment hints, creates/destroys one empty queue, and balances init/shutdown. README links the pinned API contract: null callback permitted, no submitted packets or application concurrency, no post-destroy access. Original queue-event-repro.cpp and issue draft preserved unchanged.

Helper uses named Linux KFD ioctl constants, delays background SET_EVENT 100ms, forwards real calls with original arguments/result and preserved errno, and logs completed DESTROY_EVENT plus failed SET_EVENT IDs. Removed event map/counters/destructor/synthetic failure exit from this preferred version. It is a workload-specific pointer-argument ioctl wrapper. No proposed-fix or runtime source changes. All HSA calls/process exits succeed; delayed native evidence is real event3 DESTROY success followed by event3 SET failure EINVAL, independently traced to real kernel returns.

Final sources compiled amdclang++20 with -Wall/-Wextra/-Werror against matching headers/current-develop runtime. Physical Shark52 gfx1201: plain3/3 exit0; forwarding delay0 3/3 exit0 without errors; 100ms3/3 exit0 with internal EINVAL each. Additional plain/zero-delay strace controls show no failed SET_EVENT syscall; delayed trace confirms ordering. Current revision/build reused, no redundant runtime build. No natural native crash, numerical corruption, simplified-version gfx942 execution, or same-current-head fix comparison claimed.

Preferred [workload](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/develop/simple/queue-lifecycle.cpp), [helper](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/develop/simple/delay-set-event.cpp), [contract/build/results](<TOGA_ROOT>/scratch/gfx942-nightly-implementation/event-diagnosis/develop/simple/README.md), run-receipt.json and native-strace.log in same directory. No issue/gist/push/PR edit/comment; publication remains explicitly withheld. Existing source worktrees stay home, Systems/Libraries clean; two unrelated Baritone notes preserved.
